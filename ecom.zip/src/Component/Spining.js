import React from 'react'
import myImage from './Loading.gif';
const Spining = () => {
  return (
    <div className='spinning'>
      <img src={myImage} alt="" />
    </div>
  )
}

export default Spining
